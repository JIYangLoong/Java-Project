
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Driver {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        //Object
        Staff[] currentStaff = new Staff[]{
            new NormalStaff("Chua Ying Wen", "2206776", "abc123"),
            new NormalStaff("Chua Yi Hua", "2206820", "abc123"),
            new NormalStaff("Long Ji Yang", "2206710", "abc123"),
            new Manager("Toh Chian Yi", "2206839", "abc123")};
        Book[] book = new Book[]{
            new Book("C1", "Sin City", "Comics", 20.00, 100),
            new Book("C2", "Batman: The Long Halloween", "Comics", 50.00, 100),
            new Book("C3", "Kingdom Come", "Comics", 57.00, 100),
            new Book("C4", "The Sandman", "Comics", 70.00, 100),
            new Book("C5", "Watchmen", "Comics", 35.00, 100),
            new Book("F1", "To Kill a Mockingbird by Harper Lee", "Fiction", 80.00, 100),
            new Book("F2", "A Tale of Two Cities by Charles Dickens", "Fiction", 60.10, 100),
            new Book("F3", "1984 by George Orwell and Pride", "Fiction", 128.00, 100),
            new Book("F4", "Prejudice by Jane Austen", "Fiction", 62.80, 100),
            new Book("F5", "The Great Gatsby", "Fiction", 52.90, 100),
            new Book("D1", "Pocket Dictionary", "Dictionary", 111.55, 100),
            new Book("D2", "Mini-Dictionary", "Dictionary", 92.50, 100),
            new Book("D3", "Crossword Dictionary", "Dictionary", 60.20, 100),
            new Book("D4", "Monolingual Dictionary", "Dictionary", 125.20, 100),
            new Book("D5", "Bilingual Dictionary", "Dictionary", 140.00, 100)
        };

        ArrayList<Member> membersList = new ArrayList<>();
        membersList.add(new Member("Long", "0105328855", 200));
        membersList.add(new Member("Chook", "0103366880", 50));
        membersList.add(new Member("Oren", "0103344556", 500));

        //Book[] oldBook = book;
//        //------testing------------
//        String[] bookid = {"C1", "C4"};
//        int[] qtybook = {1, 1};
//        String date = "12/09/2023";
//        Order[] orderHistory = new Order[]{new Order(bookid, qtybook, date)};
//        //-------testing------------
        Order[] orderHistory;

        int choice = 0;
        int success;
        int chance;
        int selectFirst = 0;
        String staffType = "";
        boolean logout = false;
        boolean exitProgram = false;

        //print bookstore name
        printLogo();
        System.out.println("1. Login");
        System.out.println("2. Exit program");
        System.out.print("Please select (1-2) : ");
        selectFirst = scan.nextInt();

        if (selectFirst == 2) {
            System.exit(0);
        }

        do {
            chance = 3;
            System.out.println("\nNow is " + Order.getTodayDateTimeStr());
            //Login
            do {
                success = 0;

                System.out.println("\nPlease login your staff account(X to Exit Program)");
                System.out.print("ID : ");
                String id = scan.next();
                char exit = id.charAt(0);
                if (Character.toUpperCase(exit) == 'X') {
                    System.exit(0);
                }
                System.out.print("Password : ");
                String password = scan.next();

                //Validate account
                for (Staff staffs : currentStaff) {
                    if (staffs instanceof NormalStaff) {
                        if (id.equals(staffs.getStaffId()) && password.equals(staffs.getPassword())) {
                            success++;
                            staffType = "Normal Staff";
                            System.out.println("\nWelcome " + staffs.name);
                            do {
                                logout = false;
                                staffs.printMenu();  //After validate, print menu based on the staff type

                                boolean validChoice;
                                do {
                                    try {
                                        System.out.print("Please enter your choice (1-4) : ");
                                        choice = scan.nextInt();
                                        while (choice != 1 && choice != 2 && choice != 3 && choice != 4) {
                                            System.out.print("Invalid choice.\nPlease enter again : ");
                                            choice = scan.nextInt();

                                        }
                                        validChoice = true;
                                    } catch (InputMismatchException ex) {
                                        System.out.println("Invalid input : an integer is required.");
                                        scan.nextLine();
                                        validChoice = false;
                                    }
                                } while (!validChoice);

                                //check user choice
                                switch (choice) {
                                    case 1:
                                        printBookMenu(book, staffType);
                                        boolean contOrder = wantToOrder();
                                        if (contOrder) {
                                            addNewOrder(book, membersList);
                                        }
                                        break;
                                    case 2:
                                        printBookMenu(book, staffType);
                                        addNewOrder(book, membersList);
                                        break;
                                    case 3:
                                        addNewMember(membersList);
                                        break;
                                    case 4:
                                        logout = confirmLogout();
                                        break;

                                }
                            } while (!logout);

                        }
                    } else if (staffs instanceof Manager) {
                        if (id.equals(staffs.getStaffId()) && password.equals(staffs.getPassword())) {
                            success++;
                            staffType = "Manager";
                            System.out.println("\nWelcome " + staffs.name);
                            do {
                                logout = false;
                                staffs.printMenu();  //After validate, print menu based on the staff type
                                boolean validChoice;
                                do {
                                    try {
                                        System.out.print("Please enter your choice (1-5) : ");
                                        choice = scan.nextInt();
                                        while (choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5) {
                                            System.out.print("Invalid choice.\nPlease enter again : ");
                                            choice = scan.nextInt();
                                        }
                                        validChoice = true;
                                    } catch (InputMismatchException ex) {
                                        System.out.println("Invalid input : an integer is required.");
                                        scan.nextLine();
                                        validChoice = false;
                                    }
                                } while (!validChoice);

                                //check user choice
                                switch (choice) {
                                    case 1:  //Product Management
                                        //print sub menu
                                        int selectP;
                                        do {
                                            selectP = menuProduct();
                                            switch (selectP) {
                                                case 1:
                                                    printBookMenu(book, staffType);
                                                    boolean contOrder = wantToOrder();
                                                    if (contOrder) {
                                                        addNewOrder(book, membersList);
                                                    }
                                                    break;
                                                case 2:
                                                    book = addNewBook(book);
                                                    break;
                                                case 3:
                                                    modifyBook(book);
                                                    break;
                                                case 4:
                                                    break;
                                            }
                                        } while (selectP != 4);

                                        break;
                                    case 2:  //Order Management
                                        //print sub menu
                                        int selectO;

                                        do {
                                            selectO = menuOrder();
                                            switch (selectO) {
                                                case 1:
                                                    printBookMenu(book, staffType);
                                                    addNewOrder(book, membersList);
                                                    break;
                                                case 2:
                                                    //view order history
                                                    Order.viewOrderHistory(book);
                                                    break;
                                                case 3:
                                                    break;
                                            }
                                        } while (selectO != 3);

                                        break;
                                    case 3:  //Member Management
                                        //print sub menu
                                        int selectM;
                                        do {
                                            selectM = menuMember();
                                            switch (selectM) {
                                                case 1:
                                                    addNewMember(membersList);
                                                    break;
                                                case 2:
                                                    Member.displayAllMembersDetails(membersList);
                                                    break;
                                                case 3:
                                                    if (!membersList.isEmpty()) {
                                                        searchMemberTelNo(membersList);
                                                    } else {
                                                        System.out.println("No members to search. Please add a member first.");
                                                    }
                                                    break;
                                                case 4:
                                                    if (!membersList.isEmpty()) {
                                                        modifyMemberTelNo(membersList);
                                                    } else {
                                                        System.out.println("No members to modify. Please add a member first.");
                                                    }
                                                    break;
                                                case 5:
                                                    break;
                                            }
                                        } while (selectM != 5);

                                        break;
                                    case 4:  //Generate Sales Report
                                        //System.out.println("System under maintenance.");
                                        orderHistory = Order.getOrderHistory();
                                        salesReport(orderHistory, book);
                                        break;
                                    case 5:  //Logout
                                        logout = confirmLogout();
                                        break;

                                }
                            } while (!logout);

                        }
                    }
                }
                if (success == 0) {
                    System.out.println("Invalid id and password.");
                    chance--;
                    if (chance > 0) {
                        System.out.println("Please try again. You have " + chance + " more chance.\n");
                    } else {
                        System.out.println("Sorry, you have no more chance.\n");
                        System.exit(0);
                    }

                }
            } while (success == 0 && chance > 0);
            System.out.println("1. Login");
            System.out.println("2. Exit program");
            System.out.print("Please select (1-2) : ");
            selectFirst = scan.nextInt();
        } while (selectFirst != 2);

    }

//===============================================================================================================
//Yingwen's part function
    public static void printBookMenu(Book[] book, String staff) {
        Scanner scan = new Scanner(System.in);

        System.out.println("\nCategory : ");
        System.out.println("1. Comics");
        System.out.println("2. Fiction");
        System.out.println("3. Dictionary");
        System.out.println("4. All category");
        boolean validInteger;
        int choice = 0;

        do {
            try {
                System.out.print("Please select a category to display menu (1-4) : ");
                choice = scan.nextInt();
                while (choice != 1 && choice != 2 && choice != 3 && choice != 4) {
                    System.out.print("Invalid choice.\nPlease enter again : ");
                    choice = scan.nextInt();

                }
                validInteger = true;
            } catch (InputMismatchException ex) {
                System.out.println("Invalid input : an integer is required.");
                scan.nextLine();
                validInteger = false;
            }
        } while (!validInteger);

        String category = "";
        switch (choice) {
            case 1:
                category = "Comics";
                break;
            case 2:
                category = "Fiction";
                break;
            case 3:
                category = "Dictionary";
                break;
            case 4:
                category = "All";
                break;
        }
        if (staff.equals("Normal Staff")) {
            System.out.println("\nBook Menu (Normal Staff)");
            System.out.println("==========================");
            System.out.println("Category : " + category);
            System.out.printf("%-10s %-40s %-10s %-10s\n", "Book ID", "Book Name", "Category", "Price(RM)");
            System.out.printf("%-10s %-40s %-10s %-10s\n", "-------", "---------", "--------", "---------");
            for (int i = 0; i < book.length; i++) {
                if (category.equals("Comics") || category.equals("Fiction") || category.equals("Dictionary")) {
                    if (book[i].getCategory().equals(category)) {
                        System.out.printf("%-10s %-40s %-10s %10.2f\n", book[i].getId(), book[i].getName(), book[i].getCategory(), book[i].getPrice());
                    }
                } else {
                    System.out.printf("%-10s %-40s %-10s %10.2f\n", book[i].getId(), book[i].getName(), book[i].getCategory(), book[i].getPrice());
                }
            }
        } else if (staff.equals("Manager")) {
            System.out.println("\nBook Menu (Manager)");
            System.out.println("===================");
            System.out.println("Category : " + category);
            System.out.printf("%-10s %-40s %-13s %-10s %10s\n", "Book ID", "Book Name", "Category", "Price(RM)", "Stock");
            System.out.printf("%-10s %-40s %-13s %-10s %10s\n", "-------", "---------", "--------", "---------", "-----");
            for (int i = 0; i < book.length; i++) {
                if (category.equals("Comics") || category.equals("Fiction") || category.equals("Dictionary")) {
                    if (book[i].getCategory().equals(category)) {
                        System.out.printf("%-10s %-40s %-13s %8.2f %10d\n", book[i].getId(), book[i].getName(), book[i].getCategory(), book[i].getPrice(), book[i].getStock());
                    }
                } else {
                    System.out.printf("%-10s %-40s %-13s %8.2f %10d\n", book[i].getId(), book[i].getName(), book[i].getCategory(), book[i].getPrice(), book[i].getStock());
                }
            }
        }
    }

    public static Book[] addNewBook(Book[] bookArray) {
        Scanner scanner = new Scanner(System.in);
        Book[] latestBook = null;

        while (true) {
            if (latestBook != null) {
                bookArray = latestBook;
            }
            int select = 0; // select module

            while (true) {
                System.out.println("\n1. Fiction ");
                System.out.println("2. Comic ");
                System.out.println("3. Dictionary ");

                System.out.print("\nPlease select the category (1-3): ");
                String choice = scanner.next();

                // Validation check for the input number
                if (checkThreeSelect(choice)) {
                    select = Character.getNumericValue(choice.charAt(0));

                    if (select >= 1 && select <= 3) {
                        break;
                    } else {
                        System.out.println("Invalid input. Please enter a number between 1 and 3.");
                    }
                } else {
                    System.out.println("\nInvalid input. Please enter a valid number.");
                }
            }

            switch (select) {
                case 1:
                    latestBook = addFictionBook(bookArray);
                    break;
                case 2:
                    latestBook = addComicBook(bookArray);
                    break;
                case 3:
                    latestBook = addDictionaryBook(bookArray);
                    break;
            }

            System.out.print("\nStill want to add on (Y or N): ");
            String continueAdding = scanner.next().toUpperCase();

            if (!continueAdding.equals("Y") && !continueAdding.equals("N")) {
                System.out.println("Invalid input. Please enter 'Y' to continue or 'N' to exit.");
            } else if (continueAdding.equals("N")) {
                break;
            }
        }
        return latestBook;
    }

    public static Book[] modifyBook(Book[] bookArr) {
        Scanner scan = new Scanner(System.in);
        String bookIdModify;
        boolean bookIdValid = false;
        Book[] latestBook = bookArr;
        int bookExist;
        char continueModify;

        System.out.println("Modify Book");
        System.out.println("===========");

        printBookMenu(bookArr, "Manager");
        do {
            do {
                System.out.print("\nPlease enter the book id to modify (X to exit): ");
                bookIdModify = scan.next();
                String idAfterAdjust = Character.toUpperCase(bookIdModify.charAt(0)) + bookIdModify.substring(1);
                bookIdModify = idAfterAdjust;
                //check is X or not
                if (Character.toUpperCase(bookIdModify.charAt(0)) == 'X') {
                    //break;
                    return latestBook;
                }

                //call the method in book class check book id is inside book array or not
                bookExist = checkBookId(bookArr, bookIdModify);

                while (bookExist == -1) {
                    System.out.println("Book id is not exist in the book menu. Please check again.");
                    System.out.print("Enter book id (X to exit): ");
                    bookIdModify = scan.next();
                    idAfterAdjust = Character.toUpperCase(bookIdModify.charAt(0)) + bookIdModify.substring(1);
                    bookIdModify = idAfterAdjust;
                    bookExist = checkBookId(bookArr, bookIdModify);
                }
                if (bookExist != -1) {
                    bookIdValid = true;
                }

            } while (!bookIdValid);

            System.out.println("\nPlease select the field to modify");
            System.out.println("1. Book Name");
            System.out.println("2. Category of book ");
            System.out.println("3. Book price");
            System.out.println("4. Stock");
            System.out.println("5. All");
            System.out.println("6. Exit");
//        System.out.println("Please select (1-6): ");
//        int choice = scan.nextInt();
            boolean validInteger = false;

            int choice = 0;

            do {
                try {
                    System.out.print("Please select (1-6): ");
                    choice = scan.nextInt();
                    while (choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 && choice != 6) {
                        System.out.print("Invalid choice.\nPlease enter again : ");
                        choice = scan.nextInt();
                    }
                    validInteger = true;
                } catch (InputMismatchException ex) {
                    System.out.println("Invalid input : an integer is required.");
                    scan.nextLine();
                    validInteger = false;
                }

            } while (!validInteger);
            scan.nextLine();
            switch (choice) {
                case 1:
                    String newBookName = "";
                    System.out.print("Enter new book name : ");
                    newBookName = scan.nextLine();
                    bookArr[bookExist].setName(newBookName);
                    break;
                case 2:
                    String newCategory;
                    do {
                        System.out.print("Enter new category (Fiction, Comics, Dictionary) : ");
                        newCategory = scan.next();
                    } while (!newCategory.equals("Fiction") && !newCategory.equals("Dictionary") && !newCategory.equals("Comics"));
                    bookArr[bookExist].setCategory(newCategory);
                    break;
                case 3:
                    double bookPrice = 0;
                    boolean validPrice = false;
                    do {
                        try {
                            System.out.print("Enter new price : RM ");
                            bookPrice = scan.nextDouble();
                            validInteger = true;
                        } catch (InputMismatchException ex) {
                            System.out.println("Invalid input : a double is required.");
                            scan.nextLine();
                            validInteger = false;
                        }
                    } while (!validInteger);
                    bookArr[bookExist].setPrice(bookPrice);
                    break;
                case 4:
                    int stock = 0;
                    boolean validStock = false;

                    do {
                        try {
                            System.out.print("Enter new stock : ");
                            stock = scan.nextInt();
                            validStock = true;
                        } catch (InputMismatchException ex) {
                            System.out.println("Invalid input : a double is required.");
                            scan.nextLine();
                            validStock = false;
                        }
                    } while (!validStock);
                    bookArr[bookExist].setStock(stock);
                    break;
                case 5:
                    System.out.print("Enter new book name : ");
                    newBookName = scan.nextLine();
                    bookArr[bookExist].setName(newBookName);

                    do {
                        System.out.print("Enter new category (Fiction, Comics, Dictionary) : ");
                        newCategory = scan.next();
                    } while (!newCategory.equals("Fiction") && !newCategory.equals("Dictionary") && !newCategory.equals("Comics"));
                    bookArr[bookExist].setCategory(newCategory);

                    bookPrice = 0;
                    do {
                        try {
                            System.out.print("Enter new price : RM ");
                            bookPrice = scan.nextDouble();
                            validInteger = true;
                        } catch (InputMismatchException ex) {
                            System.out.println("Invalid input : a double is required.");
                            scan.nextLine();
                            validInteger = false;
                        }
                    } while (!validInteger);
                    bookArr[bookExist].setPrice(bookPrice);

                    stock = 0;
                    do {
                        try {
                            System.out.print("Enter new stock : ");
                            stock = scan.nextInt();
                            validStock = true;
                        } catch (InputMismatchException ex) {
                            System.out.println("Invalid input : a double is required.");
                            scan.nextLine();
                            validStock = false;
                        }
                    } while (!validStock);
                    bookArr[bookExist].setStock(stock);

                    break;
                case 6:
                    return latestBook;
            }
            latestBook = bookArr;
            System.out.print("Continue to modify other book (Y-Yes, N-No) ? ");
            continueModify = Character.toUpperCase(scan.next().charAt(0));

        } while (continueModify == 'Y');

        return latestBook;
    }

    // Check if the input is a valid digit (1, 2, or 3 ) for displayBookMenu
    public static boolean checkThreeSelect(String choose) {
        return choose.length() == 1 && Character.isDigit(choose.charAt(0)) && choose.charAt(0) >= '1' && choose.charAt(0) <= '3';
    }

    public static Book[] addFictionBook(Book[] book) {
        // Fiction
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nYou selected Fiction");
        System.out.printf("\n\n");
        System.out.println("===============Fiction===============\n");

        // Declare inputFiction before the while loop
        String inputFiction = "";

        // Request user to enter the related fields to allow add on the book for fiction
        while (true) {
            System.out.printf("Enter the book code (start with F or f): ");
            inputFiction = scanner.nextLine();
            boolean isValidAddFiction = true;

            // Convert any lowercase b,f,c to uppercase
            inputFiction = inputFiction.toUpperCase();

            // Validation of book id
            // Check if the input starts with 'F' and contains only numbers after that
            if (inputFiction.length() == 0 || inputFiction.charAt(0) != 'F') {
                isValidAddFiction = false;
            } else {
                for (int i = 1; i < inputFiction.length(); i++) {
                    if (!Character.isDigit(inputFiction.charAt(i))) {
                        isValidAddFiction = false;
                        break;
                    }
                }
            }
            if (checkBookId(book, inputFiction) >= 0) {
                isValidAddFiction = false;
                System.out.println("Book ID already exist. Please try again.");
                continue;
            }

            if (!isValidAddFiction) {
                System.out.println("\nInvalid Input. The code can only contain uppercase 'F','f'");
                System.out.println("Please try again.\n");
            } else {
                break;
            }
        }

        System.out.printf("Enter the book name: ");
        String inputNameFiction = scanner.nextLine();

        //Validation of book price
        double inputPriceFiction = 0.0;
        boolean isValidPrice = false;

        while (!isValidPrice) {
            System.out.printf("Enter the book price (RM):  ");
            String inputPrice = scanner.nextLine();

            try {
                inputPriceFiction = Double.parseDouble(inputPrice);
                if (inputPriceFiction >= 0.0) {
                    isValidPrice = true;
                } else {
                    System.out.println("Invalid input. Price must be a non-negative number.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid price.");
            }
        }

        int inputQtyFiction = 0;

        while (true) {
            System.out.print("How many stock want to add on: ");
            String inputQty = scanner.nextLine();

            try {
                inputQtyFiction = Integer.parseInt(inputQty);
                // Valid input, you can use inputQtyDictionary here
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }

        System.out.printf("\n%-8s %-45s %-10s %-15s\n", "Book ID", "Book Name", "Price(RM)", "Stock");
        System.out.printf("%-8s %-45s %-1s  %-15s\n", "--------", "-------------------------------------", "---------", "---------");

        System.out.printf("%-8s %-45s %-12.2f %-5d\n", inputFiction.toUpperCase(), inputNameFiction, inputPriceFiction, inputQtyFiction);

        Book newBook = new Book(inputFiction, inputNameFiction, "Fiction", inputPriceFiction, inputQtyFiction);

        if (book == null) {
            book = new Book[1];
            book[0] = newBook;
        } else {
            java.util.List oldBook = new java.util.ArrayList(java.util.Arrays.asList(book));
            oldBook.add(newBook);
            book = (Book[]) oldBook.toArray(new Book[0]);
        }
        return book;
    }

    public static Book[] addComicBook(Book[] book) {
        // Comic
        Scanner scanner = new Scanner(System.in);
        System.out.println("You selected Comic.");
        System.out.printf("\n\n");
        System.out.println("===============Comic===============\n");

        // Declare inputComic before the while loop
        String inputComic = "";

        // Request user to enter the related fields to allow add on the book
        while (true) {
            System.out.printf("Enter the book code (start with C or c): ");
            inputComic = scanner.nextLine();
            boolean isValidAddComic = true;

            // Convert any lowercase b,f,c to uppercase
            inputComic = inputComic.toUpperCase();

            // Check if the input starts with 'C' and contains only numbers after that
            if (inputComic.length() == 0 || inputComic.charAt(0) != 'C') {
                isValidAddComic = false;
            } else {
                for (int i = 1; i < inputComic.length(); i++) {
                    if (!Character.isDigit(inputComic.charAt(i))) {
                        isValidAddComic = false;
                        break;
                    }
                }
            }

            if (checkBookId(book, inputComic) >= 0) {
                isValidAddComic = false;
                System.out.println("Book ID already exist. Please try again.");
                continue;
            }

            if (!isValidAddComic) {
                System.out.println("\nInvalid Input. The code can only contain uppercase 'C','c'");
                System.out.println("Please try again.\n");
            } else {
                break;
            }
        }

        System.out.printf("Enter the book name: ");
        String inputNameComic = scanner.nextLine();

        //Validation of book price
        double inputPriceComic = 0.0;
        boolean isValidPrice = false;

        while (!isValidPrice) {
            System.out.printf("Enter the book price (RM):  ");
            String inputPrice = scanner.nextLine();

            try {
                inputPriceComic = Double.parseDouble(inputPrice);
                if (inputPriceComic >= 0.0) {
                    isValidPrice = true;
                } else {
                    System.out.println("Invalid input. Price must be a non-negative number.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid price.");
            }
        }

        int inputQtyComic = 0;

        while (true) {
            System.out.print("How many stock want to add on: ");
            String inputQty = scanner.nextLine();

            try {
                inputQtyComic = Integer.parseInt(inputQty);
                // Valid input, you can use inputQtyDictionary here
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }

        System.out.printf("\n%-8s %-45s %-10s %-15s\n", "Book ID", "Book Name", "Price(RM)", "Stock");
        System.out.printf("%-8s %-45s %-1s  %-15s\n", "--------", "-------------------------------------", "---------", "---------");

        System.out.printf("%-8s %-45s %-12.2f %-5d\n", inputComic.toUpperCase(), inputNameComic, inputPriceComic, inputQtyComic);

        Book newBook = new Book(inputComic, inputNameComic, "Comics", inputPriceComic, inputQtyComic);

        if (book == null) {
            book = new Book[1];
            book[0] = newBook;
        } else {
            java.util.List oldBook = new java.util.ArrayList(java.util.Arrays.asList(book));
            oldBook.add(newBook);
            book = (Book[]) oldBook.toArray(new Book[0]);
        }
        return book;
    }

    public static Book[] addDictionaryBook(Book[] book) {
        Scanner scanner = new Scanner(System.in);
        // Dictionary
        System.out.println("You selected Dictionary.");
        System.out.printf("\n\n");
        System.out.println("===============Dictionary===============\n");

        // Declare inputDictionary before the loop
        String inputDictionary = "";

        // Request user to enter the related fields to allow add on the book
        while (true) {
            System.out.printf("Enter the book code (start with D or d): ");
            inputDictionary = scanner.nextLine();
            boolean isValidAddDictionary = true;

            // Convert any lowercase b,f,c to uppercase
            inputDictionary = inputDictionary.toUpperCase();

            // Check if the input starts with 'D' and contains only numbers after that
            if (inputDictionary.length() == 0 || inputDictionary.charAt(0) != 'D') {
                isValidAddDictionary = false;
            } else {
                for (int i = 1; i < inputDictionary.length(); i++) {
                    if (!Character.isDigit(inputDictionary.charAt(i))) {
                        isValidAddDictionary = false;
                        break;
                    }
                }
            }

            if (checkBookId(book, inputDictionary) >= 0) {
                isValidAddDictionary = false;
                System.out.println("Book ID already exist. Please try again.");
                continue;
            }

            if (!isValidAddDictionary) {
                System.out.println("\nInvalid Input. The code can only contain uppercase 'D','d'");
                System.out.println("Please try again.\n");
            } else {
                break;
            }
        }

        System.out.printf("Enter the book name: ");
        String inputNameDictionary = scanner.nextLine();
        //Validation of book price
        double inputPriceDictionary = 0.0;
        boolean isValidPrice = false;

        while (!isValidPrice) {
            System.out.printf("Enter the book price (RM):  ");
            String inputPrice = scanner.next();

            try {
                inputPriceDictionary = Double.parseDouble(inputPrice);
                if (inputPriceDictionary >= 0.0) {
                    isValidPrice = true;
                } else {
                    System.out.println("Invalid input. Price must be a non-negative number.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid price.");
            }
        }

        //validation of stock
        //declare before the loop
        int inputQtyDictionary = 0;

        while (true) {
            System.out.print("How many stock want to add on: ");
            String inputQty = scanner.next();

            try {
                inputQtyDictionary = Integer.parseInt(inputQty);
                // Valid input, you can use inputQtyDictionary here
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }

        System.out.printf("\n%-8s %-45s %-10s %-15s\n", "Book ID", "Book Name", "Price(RM)", "Stock");
        System.out.printf("%-8s %-45s %-1s  %-15s\n", "--------", "-------------------------------------", "---------", "---------");

        System.out.printf("%-8s %-45s %-12.2f %-5d\n", inputDictionary.toUpperCase(), inputNameDictionary, inputPriceDictionary, inputQtyDictionary);

        Book newBook = new Book(inputDictionary, inputNameDictionary, "Dictionary", inputPriceDictionary, inputQtyDictionary);

        if (book == null) {
            book = new Book[1];
            book[0] = newBook;
        } else {
            java.util.List oldBook = new java.util.ArrayList(java.util.Arrays.asList(book));
            oldBook.add(newBook);
            book = (Book[]) oldBook.toArray(new Book[0]);
        }
        return book;
    }

//===============================================================================================================
//Chianyi's part function
    public static int menuProduct() {
        Scanner scan = new Scanner(System.in);
        int option = 0;

        System.out.println("\nProduct Management Menu");
        System.out.println("=======================");
        System.out.println("1. Display product information");
        System.out.println("2. Add new product");
        System.out.println("3. Modify product");
        System.out.println("4. Exit");

        boolean validChoice;
        do {
            try {
                System.out.print("Please select an option (1-4) : ");
                option = scan.nextInt();
                while (option != 1 && option != 2 && option != 3 && option != 4) {
                    System.out.print("Invalid option. Please select again : ");
                    option = scan.nextInt();
                }
                validChoice = true;
            } catch (Exception ex) {
                System.out.println("Invalid input : an integer is required.");
                scan.nextLine();
                validChoice = false;
            }
        } while (!validChoice);

        return option;
    }

    public static int menuOrder() {
        Scanner scan = new Scanner(System.in);
        int option = 0;

        System.out.println("\nOrder Management Menu");
        System.out.println("=====================");
        System.out.println("1. Add new order");
        System.out.println("2. View order history");
        System.out.println("3. Exit");

        boolean validChoice;
        do {
            try {
                System.out.print("Please select an option (1-3) : ");
                option = scan.nextInt();
                while (option != 1 && option != 2 && option != 3) {
                    System.out.print("Invalid option. Please select again : ");
                    option = scan.nextInt();
                }
                validChoice = true;
            } catch (InputMismatchException ex) {
                System.out.println("Invalid input : an integer is required.");
                scan.nextLine();
                validChoice = false;
            }
        } while (!validChoice);

        return option;
    }

    public static int menuMember() {
        Scanner scan = new Scanner(System.in);
        int option = 0;

        System.out.println("\nMember Management Menu");
        System.out.println("======================");
        System.out.println("1. Add new member");
        System.out.println("2. Display all member");
        System.out.println("3. Search member");
        System.out.println("4. Modify member's phone number");
        System.out.println("5. Exit");

        boolean validChoice;
        do {
            try {
                System.out.print("Please select an option (1-5) : ");
                option = scan.nextInt();
                while (option != 1 && option != 2 && option != 3 && option != 4 && option != 5) {
                    System.out.print("Invalid option. Please select again : ");
                    option = scan.nextInt();
                }
                validChoice = true;
            } catch (InputMismatchException ex) {
                System.out.println("Invalid input : an integer is required.");
                scan.nextLine();
                validChoice = false;
            }
        } while (!validChoice);

        return option;
    }

    public static boolean wantToOrder() {
        Scanner scan = new Scanner(System.in);
        char input;

        do {
            System.out.print("\nDo you want to make order (Y-Yes, N-No) : ");
            input = Character.toUpperCase(scan.next().charAt(0));

            if (input != 'Y' && input != 'N') {
                System.out.println("Invalid option. Please enter Y-Yes and N-No only.");
            }
        } while (input != 'Y' && input != 'N');

        if (input == 'Y') {
            return true;
        } else {
            return false;
        }
    }

    public static int checkBookId(Book[] bookArr, String id) {
        for (int i = 0; i < bookArr.length; i++) {
            if (id.equals(bookArr[i].getId())) {
                return i;
            }
        }
        return -1;
    }

    public static int addNewOrder(Book[] bookArr, ArrayList<Member> membersList) {
        Scanner scan = new Scanner(System.in);
        char addOn;
        int i = 0;
        int j;
        double totalAmount = 0;

        int[] bookQty = new int[20];

        String[] bookId = new String[20];

        System.out.println("\nAdd New Order");
        System.out.println("==============");

        do {
            System.out.print("\nEnter book id (X to exit): ");
            bookId[i] = scan.next();
            String idAfterAdjust = Character.toUpperCase(bookId[i].charAt(0)) + bookId[i].substring(1);
            bookId[i] = idAfterAdjust;
            if (Character.toUpperCase(bookId[i].charAt(0)) == 'X') {
                //break;
                return 0;
            }

            //call the method in book class check book id is inside book array or not
            int bookExist = checkBookId(bookArr, bookId[i]);

            while (bookExist == -1) {
                System.out.println("Book id is not exist in the book menu. Please check again.");
                System.out.print("Enter book id (X to exit): ");
                bookId[i] = scan.next();
                idAfterAdjust = Character.toUpperCase(bookId[i].charAt(0)) + bookId[i].substring(1);
                bookId[i] = idAfterAdjust;
                bookExist = checkBookId(bookArr, bookId[i]);
            }

            // Exception handling : try and catch
            boolean reEnter;
            do {
                try {
                    boolean validQty;
                    do {
                        System.out.print("Enter quantity (1-99): ");
                        bookQty[i] = scan.nextInt();
                        // check the quantity entere is between 1 and 99 or not
                        if (bookQty[i] > 0 && bookQty[i] < 100) {
                            validQty = true;
                        } else {
                            System.out.println("Invalid input. Quantity only can between 1 and 99.");
                            validQty = false;
                        }
                    } while (!validQty);
                    reEnter = false;
                } catch (InputMismatchException ex) {
                    System.out.println("Invalid input : an integer between is required.");
                    //bookQty[i] = scan.nextInt();
                    scan.nextLine();
                    reEnter = true;
                }

                //check stock is enough or not
                if (bookQty[i] > bookArr[bookExist].getStock()) {
                    System.out.println("Stock is not enough. Stock available : " + bookArr[bookExist].getStock());
                    reEnter = true;
                }

            } while (reEnter);

            System.out.print("Add on product (Y- Yes / N - No)? ");
            addOn = Character.toUpperCase(scan.next().charAt(0));

            while (addOn != 'Y' && addOn != 'N') {
                System.out.println("Invalid choice. Please enter again.");
                System.out.print("Add on product (Y- Yes / N - No)? ");
                addOn = Character.toUpperCase(scan.next().charAt(0));

            }

            if (addOn == 'Y') {
                i++;
            }
        } while (addOn != 'N');

        Order o = new Order(bookId, bookQty);
        o.printOrder(bookArr);

        //MEMBER ------------------------------------------------------
        Member currentMember = null;
        double discountRate = 0;
        if (!membersList.isEmpty()) {
            currentMember = displayMemberDetails(membersList, totalAmount);
            if (currentMember != null) {
                discountRate = currentMember.discountRate();
            }
        } else {
            System.out.println("No members to display.");
        }
        double discountAmount = o.getTotalAmount() * discountRate;
        totalAmount = o.getTotalAmount() - discountAmount;

        System.out.printf("\n===========================================================================================\n");
        System.out.printf("Order Amount         : RM %.2f\n", o.getTotalAmount());
        System.out.printf("Member Discount(%d%%)  : RM %.2f\n", (int) (discountRate * 100), discountAmount);
        System.out.printf("Total Amount         : RM %.2f\n", totalAmount);

        //PAYMENT -----------------------------------------------------
        //After order, proceed to payment
        boolean payment = false;//assume
        payment = paymentPage(totalAmount);

        //deduct stock after payment successfully
        if (payment) {
            Order.saveOrder(o);
            addPoints(currentMember, totalAmount);
            for (int c = 0; c < bookId.length; c++) {
                for (int a = 0; a < bookArr.length; a++) {
                    if (bookId[c] != null) {
                        if (bookId[c].equals(bookArr[a].getId())) {
                            bookArr[a].deductStock(bookQty[c]);
                        }

                    } else {
                        break;
                    }
                }
            }

        }
        return 1;
    }

    public static void salesReport(Order[] orderHistory, Book[] book) {
        Scanner scan = new Scanner(System.in);
        SalesReport report = null;
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        boolean dateValid = false;
        int day, month, year;

        String startDateStr = "";
        String endDateStr = "";
        LocalDate startDate = null;
        LocalDate endDate = null;

        System.out.println();

        //Validation of date
        do {
            try {
                do {
                    //Start Date
                    System.out.print("Enter start date (dd/MM/yyyy) : "); //Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, ex);
                    startDateStr = scan.next();    //need date validation: check is valid day, month and year

                    String[] splitDate = startDateStr.split("/");
                    day = Integer.parseInt(splitDate[0]);
                    month = Integer.parseInt(splitDate[1]);
                    year = Integer.parseInt(splitDate[2]);

                    dateValid = false;

                    if (year >= 2000 && year <= 2023) {
                        if (year % 4 == 0) {
                            if (month > 0 && month <= 12) {
                                if (month == 2) {
                                    if (day > 0 && day <= 29) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("February in " + year + " only have 29 days.");
                                    }
                                } else if (month != 1 && month != 3 && month != 5 && month != 7 && month != 8 && month != 10 && month != 12) {
                                    if (day > 0 && day <= 30) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("Invalid date. Please enter again");
                                    }
                                } else {
                                    if (day > 0 && day <= 31) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("Invalid date. Please enter again");
                                    }
                                }
                            } else {
                                System.out.println("Invalid month. Please enter again");
                            }
                        } else {
                            if (month > 0 && month <= 12) {
                                if (month == 2) {
                                    if (day > 0 && day <= 28) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("February in " + year + " only have 28 days.");
                                    }
                                } else if (month != 1 && month != 3 && month != 5 && month != 7 && month != 8 && month != 10 && month != 12) {
                                    if (day > 0 && day <= 30) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("Invalid date. Please enter again");
                                    }
                                } else {
                                    if (day > 0 && day <= 31) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("Invalid date. Please enter again");
                                    }
                                }
                            }
                        }

                    } else {
                        System.out.println("Invalid year. Please enter again.");
                    }
                } while (!dateValid);
                startDate = LocalDate.parse(startDateStr, dateFormatter);
            } catch (Exception ex) {
                System.out.println("Invalid date. Please make sure the date entered is in dd/mm/yyyy format.");
            }
        } while (!dateValid);

        //End Date
        do {
            try {
                do {
                    //Start Date
                    System.out.print("Enter end date (dd/MM/yyyy)   : ");
                    endDateStr = scan.next();      //need date validation: check is valid day, month and year

                    String[] splitDate = endDateStr.split("/");
                    day = Integer.parseInt(splitDate[0]);
                    month = Integer.parseInt(splitDate[1]);
                    year = Integer.parseInt(splitDate[2]);

                    dateValid = false;

                    if (year >= 2000 && year <= 2023) {
                        if (year % 4 == 0) {
                            if (month > 0 && month <= 12) {
                                if (month == 2) {
                                    if (day > 0 && day <= 29) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("February in " + year + " only have 29 days.");
                                    }
                                } else if (month != 1 && month != 3 && month != 5 && month != 7 && month != 8 && month != 10 && month != 12) {
                                    if (day > 0 && day <= 30) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("Invalid date. Please enter again");
                                    }
                                } else {
                                    if (day > 0 && day <= 31) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("Invalid date. Please enter again");
                                    }
                                }
                            } else {
                                System.out.println("Invalid month. Please enter again");
                            }
                        } else {
                            if (month > 0 && month <= 12) {
                                if (month == 2) {
                                    if (day > 0 && day <= 28) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("February in " + year + " only have 28 days.");
                                    }
                                } else if (month != 1 && month != 3 && month != 5 && month != 7 && month != 8 && month != 10 && month != 12) {
                                    if (day > 0 && day <= 30) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("Invalid date. Please enter again");
                                    }
                                } else {
                                    if (day > 0 && day <= 31) {
                                        dateValid = true;
                                    } else {
                                        System.out.println("Invalid date. Please enter again");
                                    }
                                }
                            }
                        }

                    } else {
                        System.out.println("Invalid year. Please enter again.");
                    }
                } while (!dateValid);
                endDate = LocalDate.parse(endDateStr, dateFormatter);
            } catch (Exception ex) {
                System.out.println("Invalid date. Please make sure the date entered is in dd/mm/yyyy format.");
            }
        } while (!dateValid);

        report = new SalesReport(startDate, endDate);
        if (report != null) {
            report.generateSalesReport(orderHistory, book);
        }
    }
    //Chianyi's part - logout

    public static boolean confirmLogout() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Confirm logout (Y- Yes, N - No)? ");
        char confirm = Character.toUpperCase(scan.next().charAt(0));
        if (confirm == 'Y') {
            System.out.println("\nYou are successfully logged out. Thank you.\n");
            return true;
        }
        return false;
    }
//===============================================================================================================
//Long's part function

    public static boolean isMember(Member[] member, String phoneNumber) {
        // Check if the provided phone number matches the member's phone number
        if (member != null) {
            for (int i = 0; i < member.length; i++) {
                if (phoneNumber != null) {
                    if (phoneNumber.equals(member[i].getMemberTelNo())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    //-----------------------------Display Member Details (Staff)-------------------------------------------------
    public static Member displayMemberDetails(ArrayList<Member> membersList, double total) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Are you a member? (Y/N) : ");
            String response = scanner.nextLine().trim().toUpperCase();

            if (response.equals("Y")) {
                System.out.print("Enter your phone number (without dash and space) : ");
                String TelNo = scanner.nextLine();
                Member foundMember = Member.findMemberTelNo(TelNo, membersList);

//------------------------------------------Add Points----------------------------------------------------------------
                if (foundMember != null) {
                    Member correctMember = null;
                    // Compare the member
                    for (Member current : membersList) {
                        if (current.isMember(TelNo)) {
                            int currentPoints = current.getCurrentPoints();
//                            currentPoints += total;
                            current.setCurrentPoints(currentPoints);
                            current.calculateMembershipLevel();
                            current.discountRate();
                            correctMember = current;
                        }
                    }
                    System.out.println(foundMember.toString());
                    return correctMember;
                } else {
                    System.out.println("Member not found.");
                    break;
                }
            } else if (response.equals("N")) {
//                System.out.println("Member not found.");
                System.out.print("Do you want to register as a member (Y = Yes, Any Key = N) :  ");
                String register = scanner.nextLine().trim().toUpperCase();

                if (register.equals("Y")) {
                    addNewMember(membersList);
                    break;
                } else {
                    break;
                }
            } else {
                System.out.println("Invalid response. Please enter 'Y' for yes or 'N' for no.");
            }
        }
        return null;
    }

    public static void addPoints(Member current, double total) {
        if (current != null) {
            int currentPoints = current.getCurrentPoints();
            currentPoints += total;
            current.setCurrentPoints(currentPoints);
            current.calculateMembershipLevel();
        }
    }
//-----------------------------Modify Member Telephone Number--------------------------------------------------

    private static void modifyMemberTelNo(ArrayList<Member> membersList) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Enter the phone number you want to modify (without dash and spacebar) (X to exit) : ");
            String modifyTelNo = scanner.nextLine().trim().toUpperCase();

            if (modifyTelNo.equals("X")) {
                break;
            }
            boolean found = false;

            for (Member member : membersList) {
                if (member.isMember(modifyTelNo)) {
                    while (true) {
                        System.out.print("Enter new phone number (without dash and space) : ");
                        String newTelNo = scanner.nextLine();

                        //----------------------------------------Validate Member Tel No------------------------------------------------
                        if (Member.validateTelNo(newTelNo)) {
                            if (!newTelNo.equals(member.getMemberTelNo())) {
                                member.setMemberTelNo(newTelNo);
                                System.out.println("Phone number modified successfully.");
                                found = true;
                                break;
                            } else {
                                System.out.println("New phone number is the same as the old one. Please enter a different number.");
                            }
                        } else {
                            System.out.println("Invalid phone number format. Phone number must start with '01' and have exactly 10 or 11 digits.");
                        }
                    }
                    break;
                }
            }

            if (!found) {
                System.out.println("Member not found. Please try again.");
            } else {
                System.out.print("Do you want to modify another member's phone number? (Y/N) : ");
                String response = scanner.nextLine().trim().toUpperCase();
                if (!response.equals("Y")) {
                    break;
                }
            }
        }
    }

//--------------------------------------------Add Member---------------------------------------------------
    private static void addNewMember(ArrayList<Member> membersList) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Enter Member Name : ");
            String name = scanner.nextLine();
            if (name.matches("^[a-zA-Z ]+$")) {
                while (true) {
                    System.out.print("Enter Phone Number (without dash and space) : ");
                    String TelNo = scanner.nextLine();

//--------------------------------------------------------Validate Member Tel No------------------------------------------------
                    if (Member.validateTelNo(TelNo)) {
//---------------------------------------------------Validate For No Repeat TelNo--------------------------------------------------------
                        boolean noRepeatTelNo = true;
                        for (Member member : membersList) {
                            if (member.getMemberTelNo().equals(TelNo)) {
                                noRepeatTelNo = false;
                                System.out.println("Phone number already exists. Please try again.");
                                break;
                            }
                        }
//-------------------------------------------------------------------------------------------------------------------------------------
                        if (noRepeatTelNo) {
                            Member newMember = new Member(name, TelNo);
                            membersList.add(new Member(name, TelNo));
                            System.out.println("Member registered successful.");
                            System.out.println(newMember.toString());
                            return;
                        }
                    } else {
                        System.out.println("Invalid phone number format. Please try again.");
                    }
                }
            } else {
                System.out.println("Invalid name format. Please enter the name that only contains alphabets or space.");
            }
        }
    }

//-----------------------------------------Search Member Details---------------------------------------------
    private static void searchMemberTelNo(ArrayList<Member> membersList) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Enter the phone number to search (without dash and space) (or 'X' to quit) : ");
            String searchTelNo = scanner.nextLine().trim().toUpperCase();

            if (searchTelNo.equals("X")) {
                break;
            }

//----------------------------------------------------Validate for only digit----------------------------------------------------------------
            if (!searchTelNo.matches("\\d+")) {
                System.out.println("Invalid input. Please enter only digits.");
                continue;
            }

            boolean found = false;

            for (Member member : membersList) {
                String TelNo = member.getMemberTelNo();
                if (TelNo.contains(searchTelNo)) {
                    System.out.println(member.toString());
                    found = true;

                }
            }

            if (!found) {
                System.out.println("Member not found.");
            }
        }
    }

//===============================================================================================================
//Yihua's part function
    public static void printLogo() {

        System.out.println("\nLL       CCCC      BBBBB    OOOO    OOOO   KK   KK    SSSSS  TTTTTT   OOOO   RRRRR   EEEEEE");
        System.out.println("LL     CC          BB   B  OO  OO  OO  OO  KK  KK    S         TT    OO  OO  RR   R  EE");
        System.out.println("LL     CC          BBBBB   OO  OO  OO  OO  KKKK       SSSS     TT    OO  OO  RRRRR   EEEE");
        System.out.println("LL     CC          BB   B  OO  OO  OO  OO  KK  KK         S    TT    OO  OO  RR R    EE");
        System.out.println("LLLLLL   CCCC      BBBBB    OOOO    OOOO   KK   KK   SSSSS     TT     OOOO   RR   R  EEEEEE");

//        System.out.println("===========================================================================================");
//        System.out.println("________________________________________________________");
//        System.out.println("| L                         |                         :)|");
//        System.out.println("|   C                       |                       :)  |");
//        System.out.println("|     B                     |                     M     |");
//        System.out.println("|       O                   |                   E       |");
//        System.out.println("|         O                 |                 T         |");
//        System.out.println("|           K               |               S           |");
//        System.out.println("|             S             |             Y             |");
//        System.out.println("|               T           |           S               |");
//        System.out.println("|                 O         |         S                 |");
//        System.out.println("|                   R       |       O                   |");
//        System.out.println("|                     E     |     P                     |");
//        System.out.println("____________________________|___________________________");
        System.out.println("\n\nWelcome to LC Bookstore POS System!!!");

    }

    public static boolean paymentPage(double totalAmount) {
        Scanner sc = new Scanner(System.in);
        boolean paymentSuccess = false;
        do {
            System.out.println("\nPayment method ");
            System.out.println("========================");
            System.out.println("1. TNG (Touch N Go)");
            System.out.println("2. Credit/Debit Card");
            System.out.println("3. Cash");
            System.out.println("========================");

            boolean validInput;
            int paymentMethod = 0;
            do {
                try {
                    System.out.print("Select a payment method (1-3): ");
                    paymentMethod = sc.nextInt();
                    while (paymentMethod != 1 && paymentMethod != 2 && paymentMethod != 3) {
                        System.out.print("Invalid option. Please select again : ");
                        paymentMethod = sc.nextInt();
                    }
                    validInput = true;
                } catch (InputMismatchException ex) {
                    System.out.println("Invalid input : an integer is required.");
                    sc.nextLine();
                    validInput = false;
                }
            } while (!validInput);

            String method = "";
            //sc.nextLine();
            double change = 0;
            switch (paymentMethod) {
                case 1:
                    handleTNGPayment();
                    method = "Touch N Go";
                    change = 0;
                    System.out.print("\nAccount valid.");
                    break;
                case 2:
                    handleCreditCardPayment();
                    method = "Credit/Debit Card";
                    change = 0;
                    System.out.print("\nAccount valid.");
                    break;
                case 3:
                    method = "Cash";
                    System.out.println("Cash Payment");
                    break;
            }

            char inputStatus;
            String paymentStatus = "";

            System.out.print("\nPlease select the payment status (P-Paid, U-Unpaid) : ");
            inputStatus = Character.toUpperCase(sc.next().charAt(0));
            while (inputStatus != 'P' && inputStatus != 'U') {
                System.out.println("Invalid input. Please enter again.");
                System.out.print("\nPlease select the payment status (P-Paid, U-Unpaid) : ");
                inputStatus = Character.toUpperCase(sc.next().charAt(0));
            }

            double receivedAmount = 0;
            boolean validAmount = false;
            if (inputStatus == 'P') {
                paymentStatus = "Paid";
                do {
                    try {
                        System.out.print("Enter received amount : RM ");
                        receivedAmount = sc.nextDouble();
                        validAmount = true;
                    } catch (InputMismatchException ex) {
                        System.out.println("Invalid input : a double is required.");
                        validAmount = false;
                    }
                } while (!validAmount);
                receivedAmount = validateReceivedAmount(receivedAmount, totalAmount);
                change = receivedAmount - totalAmount;
            } else {
                paymentStatus = "Unpaid";
                System.out.print("Payment failed. Make payment again (Y-Yes, N-No) ?");
                if (Character.toUpperCase(sc.next().charAt(0)) == 'Y') {
                    continue;
                } else {
                    return false;
                }
            }
            paymentSuccess = true;
            printPaymentDetails(totalAmount, method, receivedAmount, change, paymentStatus);

        } while (!paymentSuccess);

        return paymentSuccess;
    }

    public static double validateReceivedAmount(double receivedAmount, double totalAmount) {
        Scanner scan = new Scanner(System.in);
        do {
            if (receivedAmount >= totalAmount) {
                return receivedAmount;
            } else {
                System.out.print("Amount not enough. Please add payment : RM ");
                receivedAmount += scan.nextDouble();
            }
        } while (receivedAmount >= totalAmount);

        return receivedAmount;
    }

    public static void handleTNGPayment() {
        Scanner sc = new Scanner(System.in);
        System.out.println("TNG Payment");
        String phoneNumber;
        do {
            System.out.print("Enter TNG phone number without dash and space (Number Only, Max 11 digits): ");
            phoneNumber = sc.nextLine();
        } while (!Member.validateTelNo(phoneNumber));

    }

    public static void handleCreditCardPayment() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Credit Card Payment");
        String creditCardNumber;
        do {
            System.out.print("Enter credit card number (16 digits, Number Only): ");
            creditCardNumber = sc.nextLine();
        } while (!validateCreditCardNumber(creditCardNumber));

    }

    private static boolean validateCreditCardNumber(String creditCardNumber) {
        //Credit Card Number mostly 16 Numbers only, so I set Must be 16 Numbers
        if (creditCardNumber.matches("^[0-9]{16}$")) {
            return true;
        } else {
            System.out.println("Invalid credit card number format. Please try again...");
            return false;
        }
    }

    public static void printPaymentDetails(double totalAmount, String paymentMethod,
            double receivedAmount, double change, String paymentStatus) {
        System.out.println("\nPayment Details");
        System.out.println("===============");
        System.out.printf("Order total amount  : RM %.2f\n", totalAmount);
        System.out.println("Payment Method      : " + paymentMethod);
        System.out.printf("Received amount     : RM %.2f\n", receivedAmount);
        System.out.printf("Change              : RM %.2f\n", change);
        System.out.println("Payment Status      : " + paymentStatus);
        System.out.println("Payment successfully! Thank you.");
    }
}
