/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jasmi
 */
import java.time.LocalDate;

public class SalesReport {

    private LocalDate startDate;
    private LocalDate endDate;
    private int[] qtySold = new int[20];
    private double[] amountSold = new double[20];
    private double totalAmount;

    public SalesReport() {
        this(null, null);
    }

    public SalesReport(LocalDate startDate, LocalDate endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public int[] getQtySold() {
        return qtySold;
    }

    public void setQtySold(int[] qtySold) {
        this.qtySold = qtySold;
    }

    public double[] getAmountSold() {
        return amountSold;
    }

    public void setAmountSold(double[] amountSold) {
        this.amountSold = amountSold;
    }

    public double calculateTotalAmount() {
        for (int i = 0; i < amountSold.length; i++) {
            this.totalAmount += amountSold[i]; //try to change to the foreach loop
        }

        return this.totalAmount;
    }

//    public static LocalDate convertDateToLocalDate(Date dateToConvert) {
//        return new java.sql.Date(dateToConvert.getTime()).toLocalDate();
//    }
    public void generateSalesReport(Order[] orderHistory, Book[] bookArr) {
        System.out.println("\nSales Report");
        System.out.println("==============");

        System.out.println("Start Date : " + this.startDate);
        System.out.println("End Date   : " + this.endDate);

        //print table header
        System.out.printf("\n%-10s %-40s %10s %20s %15s %20s\n", "Book Code", "Book Name", "Price(RM)", "Quantity Sold", "Current Stock", "Amount Sold(RM)");
        System.out.printf("%-10s %-40s %10s %20s %15s %20s\n", "---------", "----------", "----------", "-------------", "-------------", "----------------");

        boolean dateBetween = false;
        if (orderHistory != null) {
            for (int f = 0; f < orderHistory.length; f++) {

                //Check the order date is between start and end date
                if (orderHistory[f].getOrderDate().isAfter(startDate) && orderHistory[f].getOrderDate().isBefore(endDate)) {
                    dateBetween = true;
                }

                if (dateBetween) {
                    String[] bookId = orderHistory[f].getBookId();
                    int[] bookQty = orderHistory[f].getQtyBook();

                    for (int u = 0; u < bookId.length && bookId[u] != null; u++) {
                        for (int i = 0; i < bookArr.length; i++) {
                            if (bookId[u].equals(bookArr[i].getId())) {
                                qtySold[i] += bookQty[u];
                                amountSold[i] = qtySold[i] * bookArr[i].getPrice();
                            }
                        }
                    }

                }

            }
        }
        //correct der
        for (int i = 0; i < bookArr.length; i++) {
            System.out.printf("%-10s %-40s %10.2f %20d %15d %20.2f\n", bookArr[i].getId(), bookArr[i].getName(), bookArr[i].getPrice(), qtySold[i], bookArr[i].getStock(), amountSold[i]);
        }

        System.out.printf("\n\nTotal Amount Sold : RM %.2f\n", this.calculateTotalAmount());

    }
}
