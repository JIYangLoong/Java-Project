/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author User
 */
import java.util.ArrayList;

public class Member {

    static boolean toString;

    private String memberId;
    private String memberName;
    private String memberTelNo;
    private String membershipLevel;
    private int currentPoints = 0;
    private double discountRate;

    public Member(String memberName, String memberTelNo, int currentPoints) {
        this.memberName = memberName;
        this.memberTelNo = memberTelNo;
        this.currentPoints = currentPoints;
        calculateMembershipLevel();
        discountRate();
    }

    public Member(String memberName, String memberTelNo) {
        this.memberName = memberName;
        this.memberTelNo = memberTelNo;
        this.currentPoints = 0;
        calculateMembershipLevel();
        discountRate();
    }

    public Member() {
        this("", "", 0);
    }

    public static boolean isToString() {
        return toString;
    }

    public String getMemberId() {
        return memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public String getMemberTelNo() {
        return memberTelNo;
    }

    public String getMembershipLevel() {
        return membershipLevel;
    }

    public int getCurrentPoints() {
        return currentPoints;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public static void setToString(boolean toString) {
        Member.toString = toString;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public void setMemberTelNo(String memberTelNo) {
        this.memberTelNo = memberTelNo;
    }

    public void setMembershipLevel(String membershipLevel) {
        this.membershipLevel = membershipLevel;
    }

    public void setCurrentPoints(int currentPoints) {
        this.currentPoints = currentPoints;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

//-----------------------------------------------------------DisplayMember(Manager)----------------------------------------------------------------------------------
    public boolean isMember(String phoneNumber) {
        // Check if the provided phone number matches the member's phone number
        return phoneNumber.equals(this.memberTelNo);
    }

    @Override
    public String toString() {
        return "\nMember Details\n"
                + "----------------\n"
                + "Member Name : " + memberName
                + "\nMember TelNo : " + memberTelNo
                + "\nCurrent Points : " + currentPoints
                + "\nMembership Level : " + membershipLevel
                + "\nDiscount Rate(%) : " + discountRate() * 100;
    }

    static void displayAllMembersDetails(ArrayList<Member> membersList) {
        for (Member member : membersList) {
            System.out.println(member.toString());
        }
    }

//-------------------------------------------------------------AddMember------------------------------------------------------------------------------------
    public void calculateMembershipLevel() {
        if (currentPoints >= 500) {
            membershipLevel = "Platinum";
        } else if (currentPoints >= 200 && currentPoints < 500) {
            membershipLevel = "Gold";
        } else if (currentPoints >= 50 && currentPoints < 200) {
            membershipLevel = "Silver";
        } else {
            membershipLevel = "Normal";
        }
    }

    public double discountRate() {
        if (currentPoints >= 50 && currentPoints < 200) {
            return 0.03; //3% discount
        } else if (currentPoints >= 200 && currentPoints < 500) {
            return 0.05; //5% discount
        } else if (currentPoints >= 500) {
            return 0.10; //10% discount;
        } else {
            return 0.0;
        }
    }

//--------------------------------------------------Compare the Member Phone Number----------------------------------------------------------------
    public static Member findMemberTelNo(String TelNo, ArrayList<Member> membersList) {
        for (Member member : membersList) {
            if (member.isMember(TelNo)) {
                return member;
            }
        }
        return null; // Member not found
    }

//------------------------------------------------------------------------Modify Member----------------------------------------------------------------------
    public static boolean validateTelNo(String TelNo) {
        return TelNo.matches("^(01\\d{8}||01\\d{9})$");
    }
//------------------------------------------------------------------------Search Member----------------------------------------------------------------------
}
