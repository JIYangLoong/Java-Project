/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jasmi
 */
public class Manager extends Staff {

    private String managerId;
    private String password;

    public Manager(String name, String managerId, String password) {
        super(name);
        this.managerId = managerId;
        this.password = password;
    }

    @Override
    public String getStaffId() {
        return managerId;
    }

    public void setManagerId(String managerId) {
        this.managerId = managerId;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public void printMenu() {
        System.out.println("\nManager Menu : ");
        System.out.println("1. Product management");
        System.out.println("2. Order management");
        System.out.println("3. Member management");
        System.out.println("4. Generate sales report");
        System.out.println("5. Logout");
        //System.out.print("Please enter your choice (1-5) : ");
    }
}
