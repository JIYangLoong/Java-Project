
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Order {

    //-----------------Data Field----------------------
    private int orderNo;
    //private java.util.Date orderDate;
    private String orderDateStr;
    private LocalDate orderDate;
    private int noOfItem;
    private double subtotal;
    private String orderStatus;
    private double totalAmount;
    private double sstAmount;
    final static double sstRate = 0.06;

    private String[] bookId;
    private int[] qtyBook;
    private double[] bookPrice = new double[100];

    public static int lastAssignedNo = 100;

    private static Order[] orderHistory;

    //---------------------------Constructor------------------------------------------------
    public Order() {
        this(null, null);
        this.orderDate = getTodayDate();
        this.orderDateStr = getTodayDateTimeStr();
        this.orderNo = lastAssignedNo;
        Order.lastAssignedNo++;
        //this.saveOrder(this);
    }

    public Order(String[] bookId, int[] qtyBook) {
        this.bookId = bookId;
        this.qtyBook = qtyBook;
        this.orderDate = getTodayDate();
        this.orderDateStr = getTodayDateTimeStr();
        this.orderNo = lastAssignedNo;
        Order.lastAssignedNo++;
        //this.saveOrder(this);
    }

    public Order(String[] bookId, int[] qtyBook, String orderDate) {
        this.bookId = bookId;
        this.qtyBook = qtyBook;
        this.orderDate = this.convertToLocalDate(orderDate);
        this.orderNo = lastAssignedNo;
        Order.lastAssignedNo++;
        this.saveOrder(this);

    }

    //----------------------------------------setter and getter---------------------------------
    public int getOrderNo() {
        return this.orderNo;
    }

    public void setOrderNo(int orderNo) {
        this.orderNo = orderNo;
    }

    public String[] getBookId() {
        return bookId;
    }

    public void setBookId(String[] bookId) {
        this.bookId = bookId;
    }

//    public static void setBookArray(Book[] bookArr) {
//        bookArr = bookArr;
//    }
    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderDateStr() {
        return orderDateStr;
    }

    public void setOrderDateStr(String orderDate) {
        this.orderDateStr = orderDate;
    }

    public int getNoOfItem() {
        return noOfItem;
    }

    public void setNoOfItem(int noOfItem) {
        this.noOfItem = noOfItem;
    }

    public int[] getQtyBook() {
        return qtyBook;
    }

    public void setQtyBook(int[] qtyBook) {
        this.qtyBook = qtyBook;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public static Order[] getOrderHistory() {
        return orderHistory;
    }

    public static LocalDate getTodayDate() {
        java.time.LocalDate date = java.time.LocalDate.now();
//        java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
//        String date = dateObj.format(formatter);
        return date;
    }

    public static String getTodayDateTimeStr() {
        LocalDateTime dateObj = LocalDateTime.now();
        java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String date = dateObj.format(formatter);
        return date;
    }

    public LocalDate convertToLocalDate(String dateStr) {
        java.time.format.DateTimeFormatter dateFormat = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate date = LocalDate.parse(dateStr, dateFormat);
        return date;
    }

    //--------------------------------function-----------------------------------------------
    public double calculateSubtotal() {
        //need the book class info to implement this calculation
        double sub = 0;
        for (int i = 0; i < bookId.length; i++) {
            sub += bookPrice[i] * qtyBook[i];
        }
        this.subtotal = sub;

        return this.subtotal;
    }

    public double calculateTotal() {
        this.sstAmount = this.subtotal * sstRate;
        this.totalAmount = this.subtotal + this.sstAmount;
        return this.totalAmount;
        //check is a member, apply discount

    }

    public void printOrder(Book[] bookArr) {
        System.out.printf("\n===========================================================================================");
        System.out.println("\nOrder No : " + this.orderNo);
        System.out.println("Order Time : " + this.orderDateStr);
        System.out.printf("%-4s %-40s %-10s %-14s %-15s\n", "Id", "Book Name", "Quantity", "Unit price(RM)", "   Total price(RM)");
        System.out.printf("%-4s %-40s %-10s %-14s %-15s\n", "---", "---------", "--------", "--------------", "   ---------------");

        for (int i = 0; i < bookId.length; i++) {

            if (bookId[i] != null) {
                //check the book id is in the bookArr list or not
                for (Book book : bookArr) {
                    if (bookId[i].equals(book.getId())) {
                        bookPrice[i] = book.getPrice();
                        System.out.printf("%-4s %-40s %-10d %-14.2f    %-15.2f\n", bookId[i], book.getName(), qtyBook[i], book.getPrice(), bookPrice[i] * qtyBook[i]);
                        break;
                    }
                }
            }
        }
        System.out.printf("\n===========================================================================================");
        System.out.printf("\nSubtotal     : RM %.2f\n", this.calculateSubtotal());
        this.totalAmount = this.calculateTotal();
        System.out.printf("SST (6%%)     : RM %.2f\n", this.sstAmount);
        System.out.printf("Total Amount : RM %.2f\n", this.totalAmount);
        System.out.printf("===========================================================================================\n");
    }

    public static void saveOrder(Order newOrder) {
        if (orderHistory == null) {
            Order.orderHistory = new Order[1];
            Order.orderHistory[0] = newOrder;
        } else {
            java.util.List orderHis = new java.util.ArrayList(java.util.Arrays.asList(Order.orderHistory));
            orderHis.add(newOrder);
            Order.orderHistory = (Order[]) orderHis.toArray(new Order[0]);
        }
    }

    public static void viewOrderHistory(Book[] bookArr) {
        System.out.println("\n\nOrder History");
        System.out.println("==============");
        if (orderHistory != null) {
            for (int i = 0; i < orderHistory.length; i++) {
                System.out.println("\nOrder No : " + orderHistory[i].orderNo);
                System.out.println("Order time : " + orderHistory[i].orderDateStr);
                System.out.println("Order book details : ");
                System.out.printf("%-4s %-40s %-10s %-14s %-15s\n", "Id", "Book Name", "Quantity", "Unit price(RM)", "   Total price(RM)");
                System.out.printf("%-4s %-40s %-10s %-14s %-15s\n", "---", "---------", "--------", "--------------", "   ---------------");

                for (int j = 0; j < orderHistory[i].bookId.length; j++) {

                    if (orderHistory[i].bookId[j] != null) {
                        //check the book id is in the bookArr list or not
                        for (Book book : bookArr) {
                            if (orderHistory[i].bookId[j].equals(book.getId())) {
                                orderHistory[i].bookPrice[j] = book.getPrice();
                                System.out.printf("%-4s %-40s %-10d %-14.2f    %-15.2f\n", orderHistory[i].bookId[j], book.getName(), orderHistory[i].qtyBook[j], book.getPrice(), orderHistory[i].bookPrice[j] * orderHistory[i].qtyBook[j]);
                                break;
                            }
                        }
                    }
                }
                System.out.println("----------------------------------");
                System.out.printf("Order subtotal     : RM %.2f\n", orderHistory[i].subtotal);
                System.out.printf("Order SST amount   : RM %.2f\n", orderHistory[i].sstAmount);
                System.out.printf("Order total amount : RM %.2f\n", orderHistory[i].totalAmount);
                System.out.println("----------------------------------");
            }
        }
    }
}
