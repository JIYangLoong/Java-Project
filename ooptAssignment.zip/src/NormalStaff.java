/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jasmi
 */
public class NormalStaff extends Staff {

    private String staffId;
    private String password;

    public NormalStaff(String name, String staffId, String password) {
        super(name);
        this.staffId = staffId;
        this.password = password;
    }

    @Override
    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public void printMenu() {
        System.out.println("\nStaff Menu : ");
        System.out.println("1. Display product menu");
        System.out.println("2. Add new order");
        System.out.println("3. Add new member");
        System.out.println("4. Logout");
        //System.out.print("Please enter your choice (1-4) : ");
    }

}
